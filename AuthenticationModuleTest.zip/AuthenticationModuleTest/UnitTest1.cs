using NUnit.Framework;
using Microsoft.AspNetCore.Mvc;
using System;
using Authorization.Controllers;
using Authorization.Models;

namespace AuthenticationModuleTest
{
    public class Tests
    {
        private AuthController authController;
        LoginModel user1;
        LoginModel user2;
        [SetUp]
        public void Setup()
        {
            user1 = new LoginModel()
            { 
                UserName = "abcdef",
                Password = "raj123"
            };
            user2 = new LoginModel()
            {
                UserName = "qwerty",
                Password = "spider"
            };

        }

        [Test]
        public void Test1()
        {
            authController = new AuthController();
            var result = authController.Login(user1);
            Assert.IsNotNull(result);
        }

        [Test]
        public void Test2()
        {
            authController = new AuthController();
            var result = authController.Login(user1);
            Assert.IsNull(result);
        }
        [Test]
        public void AuthControllerPositiveTest()
        {

            try
            {
                var result = authController.Login(user2);
                var response = result as ObjectResult;
                Assert.AreEqual(401, response.StatusCode);
            }
            catch (Exception e)
            {
                Assert.AreEqual("Object reference not set to an instance of an object.", e.Message);
            }
        }
        [Test]
        public void AuthControlleNegativeTest()
        {
            var result = authController.Login(user2);
            var response = result as ObjectResult;
            Assert.AreEqual(400, response.StatusCode);
            Assert.That(response.StatusCode, Is.EqualTo("400"));
        }

    }
}