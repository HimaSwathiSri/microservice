﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditBenchmarkModule.Models
{
    public class AuditBenchmark
    {
        public string auditType { get; set; }
        public int benchmarkNoAnswers { get; set; }
    }
}
