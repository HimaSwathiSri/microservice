﻿namespace AuditBenchmarkModule.Data
{
    public class DataContext
    {
    }
}
