﻿namespace AuditBenchmarkTesting
{
    internal class BadRequestResult
    {
        public double StatusCode { get; internal set; }
    }
}