﻿namespace AuditBenchmarkTesting
{
    internal class OkObjectResult
    {
        public double StatusCode { get; internal set; }
    }
}